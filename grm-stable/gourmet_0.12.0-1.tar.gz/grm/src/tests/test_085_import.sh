rm 085_setup/*.db
rm 085_setup/GOURMET_DATA*
gourmet --gourmet-directory=085_setup/
