rm 09_setup/*.db
rm 09_setup/GOURMET_DATA*
gourmet --gourmet-directory=09_setup/
