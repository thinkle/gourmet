#
# Regular cron jobs for the gourmet package
#
0 4	* * *	root	gourmet_maintenance
