# Copyright (c) 2002 Juri Pakaste
# You may use and distribute this software under the terms of the
# GNU General Public License, version 2 or later

cvs_id = "$Id: __init__.py,v 1.5 2005/04/16 13:12:51 thomas_hinkle Exp $"

APPNAME = "Gourmet"
VERSION = "0.2.2"

import os.path
import gglobals
import defaults
import converter
import keymanager
import options
