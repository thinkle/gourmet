# Defaults for gourmet initscript
# sourced by /etc/init.d/gourmet
# installed at /etc/default/gourmet by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
